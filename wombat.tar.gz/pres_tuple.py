from collections import namedtuple

fields = 'term firstname lastname birthplace birthstate party'
President = namedtuple('President', fields)
